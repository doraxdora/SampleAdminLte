$(function () {

	// テーブルの設定
	$('#dataTable').DataTable({
		'paging'		: true,
		'pageLength'	: 5,
		'lengthChange'	: false,
		'searching'	 	: false,
		'ordering'		: true,
		'info'			: true,
		'autoWidth'	 	: true,
		'scrollX'		: true,
		'tabIndex'	: -1,
		'order'			: [[ 0, 'desc' ]],
		'columnDefs'	: [
			{ targets: 0, width: 60 },
			{ targets: 1, width: 70 },
			{ targets: 2, width: 90 },
			{ targets: 3, width: 50 },
			{ targets: 4, width: 80 },
		],
		"language"   : {
			"decimal":			".",
			"emptyTable":	 	"表示するデータがありません。",
			"info":		   		"_START_ ～ _END_ / _TOTAL_ 件中",
			"infoEmpty":	  	"0 ～ 0 / 0 件",
			"infoFiltered":   	"(合計 _MAX_ 件からフィルタリングしています)",
			"infoPostFix":		"",
			"thousands":	 	 ",",
			"lengthMenu":	 	"1ページ _MENU_ 件を表示する",
			"loadingRecords": 	"読み込み中...",
			"processing":	 	"処理中...",
			"search":		 	"絞り込み:",
			"zeroRecords":		"一致するデータが見つかりません。",
			"paginate": {
				"first":		"最初",
				"last":	   		"最後",
				"next":	   		"次",
				"previous":		"前"
			}
		}
	});

	// Make the dashboard widgets sortable Using jquery UI
	$('.connectedSortable').sortable({
		placeholder				: 'sort-highlight',
		connectWith				: '.connectedSortable',
		handle					: '.box-header, .nav-tabs',
		forcePlaceholderSize	: true,
		zIndex					: 999999
	});
	$('.connectedSortable .box-header, .connectedSortable .nav-tabs-custom').css('cursor', 'move');

	// jQuery UI sortable for the todo list
	$('.todo-list').sortable({
		placeholder			: 'sort-highlight',
		handle				: '.handle',
		forcePlaceholderSize: true,
		zIndex				: 999999
	});

	/* ChartJS
	 * -------
	 * Here we will create a few charts using ChartJS
	 */
	var areaChartData = {
		labels	: [
			'04',
			'05',
			'06',
			'07',
			'08',
			'09',
			'10',
			'11',
			'12',
			'01',
			'02',
			'03'],
		datasets: [
			{
				label				: '実績',
				fillColor			: 'rgba(210, 214, 222, 1)',
				strokeColor			: 'rgba(210, 214, 222, 1)',
				pointColor			: 'rgba(210, 214, 222, 1)',
				pointStrokeColor	: '#c1c7d1',
				pointHighlightFill	: '#fff',
				pointHighlightStroke: 'rgba(220,220,220,1)',
				data				: [651, 595, 808, 815, 564, 554, 401]
			},
			{
				label				: '予定',
				fillColor			: 'rgba(60,141,188,0.9)',
				strokeColor			: 'rgba(60,141,188,0.8)',
				pointColor			: '#3b8bba',
				pointStrokeColor	: 'rgba(60,141,188,1)',
				pointHighlightFill	: '#fff',
				pointHighlightStroke: 'rgba(60,141,188,1)',
				data				: [281, 484, 406, 194, 864, 271, 904]
			}
		]
	}

	var areaChartOptions = {
		showScale				: true,
		scaleShowGridLines		: true,
		scaleGridLineColor		: 'rgba(0,0,0,.05)',
		scaleGridLineWidth		: 1,
		scaleShowHorizontalLines: true,
		scaleShowVerticalLines	: true,
		scaleLabel				:"<%=new Intl.NumberFormat().format(value) %> H",
		bezierCurve				: true,
		bezierCurveTension		: 0.3,
		pointDot				: false,
		pointDotRadius			: 4,
		pointDotStrokeWidth		: 1,
		pointHitDetectionRadius : 20,
		datasetStroke			: true,
		datasetStrokeWidth		: 2,
		datasetFill				: true,
		legendTemplate			: '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
		maintainAspectRatio		: true,
		responsive				: true
	};

	//-------------
	//- LINE CHART -
	//--------------
	var lineChartCanvas				= $('#lineChart').get(0).getContext('2d')
	var lineChart					= new Chart(lineChartCanvas)
	var lineChartOptions			= areaChartOptions
	lineChartOptions.datasetFill	= false
	lineChart.Line(areaChartData, lineChartOptions)


	// The Calender
	$('#calendar').datepicker();

	// -------------
	// - PIE CHART -
	// -------------
	var pieChartCanvas = $('#pieChart').get(0).getContext('2d');
	var pieChart	= new Chart(pieChartCanvas);
	var PieData		= [
		{
			value		: 20542,
			color		: '#f56954',
			highlight	: '#f56954',
			label		: '交通費'
		},
		{
			value		: 4250,
			color		: '#00a65a',
			highlight	: '#00a65a',
			label		: '会議費'
		},
		{
			value		: 8400,
			color		: '#f39c12',
			highlight	: '#f39c12',
			label		: '旅費交通費'
		},
		{
			value		: 1200,
			color		: '#00c0ef',
			highlight	: '#00c0ef',
			label		: '福利厚生費'
		},
		{
			value		: 6000,
			color		: '#3c8dbc',
			highlight	: '#3c8dbc',
			label		: '交際費'
		},
		{
			value		: 9000,
			color		: '#d2d6de',
			highlight	: '#d2d6de',
			label		: '日当'
		}
	];
	var pieOptions		 = {
		segmentShowStroke		: true,
		segmentStrokeColor		: '#fff',
		segmentStrokeWidth		: 1,
		percentageInnerCutout	: 50, // This is 0 for Pie charts
		animationSteps			: 100,
		animationEasing			: 'easeOutBounce',
		animateRotate			: true,
		animateScale			: false,
		responsive				: true,
		maintainAspectRatio		: false,
		legendTemplate			: '<ul class=\'<%=name.toLowerCase()%>-legend\'><% for (var i=0; i<segments.length; i++){%><li><span style=\'background-color:<%=segments[i].fillColor%>\'></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>',
		tooltipTemplate			: '<%=label%> <%=new Intl.NumberFormat().format(value) %>円'
	};
	// Create pie or douhnut chart
	// You can switch between pie and douhnut using the method below.
	pieChart.Doughnut(PieData, pieOptions);
	// -----------------
	// - END PIE CHART -
	// -----------------
});
